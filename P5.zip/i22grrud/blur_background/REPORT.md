# Lo que he hecho

Lo he hecho todo, en algunas funciones he necesitado ayuda de chat gpt
# Lo que no he hecho

# Enlace al vídeo descriptivo
No lo he hecho
'
