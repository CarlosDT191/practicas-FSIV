# Suavizado del Fondo basado en Flujo Óptico

La descripción de la práctica la tienes [aquí](https://docs.google.com/document/d/1QDUk6cMhwYSoncrG8W5uyofB0ZSlY1H9U6BIQ0wcy98/edit?usp=sharing).

